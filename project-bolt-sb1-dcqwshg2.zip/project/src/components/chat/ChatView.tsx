import React, { useEffect, useRef } from 'react';
import { useQuery, useSubscription, gql } from '@apollo/client';
import { useUserData } from '@nhost/react';
import { Users } from 'lucide-react';
import MessageInput from './MessageInput';

const GET_MESSAGES = gql`
  query GetMessages($chatId: uuid!) {
    messages(
      where: { chat_id: { _eq: $chatId } }
      order_by: { created_at: asc }
    ) {
      id
      content
      created_at
      user {
        id
        email
      }
    }
  }
`;

const MESSAGES_SUBSCRIPTION = gql`
  subscription MessagesSubscription($chatId: uuid!) {
    messages(
      where: { chat_id: { _eq: $chatId } }
      order_by: { created_at: asc }
    ) {
      id
      content
      created_at
      user {
        id
        email
      }
    }
  }
`;

const GET_CHAT_INFO = gql`
  query GetChatInfo($chatId: uuid!) {
    chats_by_pk(id: $chatId) {
      id
      name
      participants {
        user {
          id
          email
        }
      }
    }
  }
`;

interface ChatViewProps {
  chatId: string;
}

const ChatView: React.FC<ChatViewProps> = ({ chatId }) => {
  const user = useUserData();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { data: chatData } = useQuery(GET_CHAT_INFO, {
    variables: { chatId },
  });

  const { data: messagesData } = useSubscription(MESSAGES_SUBSCRIPTION, {
    variables: { chatId },
  });

  const messages = messagesData?.messages || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const chat = chatData?.chats_by_pk;
  const otherParticipants = chat?.participants.filter(
    (p: any) => p.user.id !== user?.id
  ) || [];

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 p-6">
        <div className="flex items-center space-x-4">
          <div className="bg-gradient-to-r from-blue-400 to-purple-500 w-12 h-12 rounded-full flex items-center justify-center">
            {chat?.name ? (
              <span className="text-white font-medium text-lg">
                {chat.name[0].toUpperCase()}
              </span>
            ) : (
              <Users className="w-6 h-6 text-white" />
            )}
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              {chat?.name || otherParticipants.map((p: any) => p.user.email).join(', ')}
            </h2>
            <p className="text-sm text-gray-500">
              {otherParticipants.length} participant{otherParticipants.length !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-gray-500">No messages yet</p>
              <p className="text-sm text-gray-400">Start the conversation!</p>
            </div>
          </div>
        ) : (
          messages.map((message: any) => {
            const isOwn = message.user.id === user?.id;
            return (
              <div
                key={message.id}
                className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-xs lg:max-w-md xl:max-w-lg ${isOwn ? 'order-2' : 'order-1'}`}>
                  <div
                    className={`px-4 py-3 rounded-2xl ${
                      isOwn
                        ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                  <div className={`mt-1 text-xs text-gray-500 ${isOwn ? 'text-right' : 'text-left'}`}>
                    {!isOwn && <span className="font-medium">{message.user.email} • </span>}
                    {formatTime(message.created_at)}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 p-6">
        <MessageInput chatId={chatId} />
      </div>
    </div>
  );
};

export default ChatView;