import React from 'react';
import { useQuery, gql } from '@apollo/client';
import { useUserData } from '@nhost/react';
import { Users, Plus } from 'lucide-react';

const GET_CHATS = gql`
  query GetChats($userId: uuid!) {
    chats(where: { participants: { user_id: { _eq: $userId } } }) {
      id
      name
      created_at
      messages(limit: 1, order_by: { created_at: desc }) {
        content
        created_at
        user {
          email
        }
      }
      participants {
        user {
          id
          email
        }
      }
    }
  }
`;

interface ChatListProps {
  selectedChatId: string | null;
  onSelectChat: (chatId: string) => void;
}

const ChatList: React.FC<ChatListProps> = ({ selectedChatId, onSelectChat }) => {
  const user = useUserData();
  const { data, loading } = useQuery(GET_CHATS, {
    variables: { userId: user?.id },
    skip: !user?.id,
  });

  if (loading) {
    return (
      <div className="p-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="mb-3">
            <div className="bg-gray-200 animate-pulse h-16 rounded-lg"></div>
          </div>
        ))}
      </div>
    );
  }

  const chats = data?.chats || [];

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <div className="p-4 space-y-2">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Chats</h3>
        <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
          <Plus className="w-5 h-5" />
        </button>
      </div>
      
      {chats.length === 0 ? (
        <div className="text-center py-8">
          <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No chats yet</p>
          <p className="text-sm text-gray-400">Start a new conversation</p>
        </div>
      ) : (
        chats.map((chat: any) => {
          const lastMessage = chat.messages[0];
          const otherParticipants = chat.participants.filter(
            (p: any) => p.user.id !== user?.id
          );
          
          return (
            <button
              key={chat.id}
              onClick={() => onSelectChat(chat.id)}
              className={`w-full p-4 text-left rounded-xl transition-all hover:bg-gray-50 ${
                selectedChatId === chat.id
                  ? 'bg-blue-50 border-2 border-blue-200'
                  : 'border-2 border-transparent'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <div className="bg-gradient-to-r from-blue-400 to-purple-500 w-10 h-10 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">
                        {chat.name ? chat.name[0].toUpperCase() : 'C'}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 truncate">
                        {chat.name || otherParticipants.map((p: any) => p.user.email).join(', ')}
                      </h4>
                      {lastMessage && (
                        <p className="text-sm text-gray-600 truncate">
                          {lastMessage.user.email === user?.email ? 'You: ' : ''}
                          {lastMessage.content}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                {lastMessage && (
                  <span className="text-xs text-gray-400 ml-2">
                    {formatTime(lastMessage.created_at)}
                  </span>
                )}
              </div>
            </button>
          );
        })
      )}
    </div>
  );
};

export default ChatList;