import React, { useState } from 'react';
import { useMutation, gql } from '@apollo/client';
import { useUserData } from '@nhost/react';
import { Send, Loader } from 'lucide-react';

const SEND_MESSAGE = gql`
  mutation SendMessage($chatId: uuid!, $content: String!, $userId: uuid!) {
    insert_messages_one(
      object: { chat_id: $chatId, content: $content, user_id: $userId }
    ) {
      id
      content
      created_at
      user {
        id
        email
      }
    }
  }
`;

interface MessageInputProps {
  chatId: string;
}

const MessageInput: React.FC<MessageInputProps> = ({ chatId }) => {
  const [message, setMessage] = useState('');
  const user = useUserData();
  
  const [sendMessage, { loading }] = useMutation(SEND_MESSAGE, {
    onCompleted: () => {
      setMessage('');
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !user?.id || loading) return;

    await sendMessage({
      variables: {
        chatId,
        content: message.trim(),
        userId: user.id,
      },
    });
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-end space-x-4">
      <div className="flex-1">
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
          placeholder="Type a message..."
          className="w-full px-4 py-3 border border-gray-300 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
          rows={1}
          style={{
            minHeight: '48px',
            maxHeight: '120px',
          }}
        />
      </div>
      <button
        type="submit"
        disabled={!message.trim() || loading}
        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-3 rounded-xl hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
      >
        {loading ? (
          <Loader className="w-5 h-5 animate-spin" />
        ) : (
          <Send className="w-5 h-5" />
        )}
      </button>
    </form>
  );
};

export default MessageInput;