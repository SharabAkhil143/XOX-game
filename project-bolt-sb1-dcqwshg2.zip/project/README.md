# ChatFlow - Real-time Chat Application

A modern React chat application built with Nhost authentication, Apollo GraphQL, and real-time subscriptions.

## 🚀 Features

- **Authentication**: Email-based sign-up and sign-in with Nhost Auth
- **Protected Routes**: Secure chat interface accessible only to authenticated users
- **Real-time Messaging**: GraphQL subscriptions for instant message updates
- **Modern UI**: Beautiful, responsive design with Tailwind CSS
- **GraphQL Integration**: Apollo Client for efficient data management

## 🛠️ Technologies

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Authentication**: Nhost Auth
- **Database & API**: Hasura GraphQL via Nhost
- **Real-time**: GraphQL Subscriptions
- **State Management**: Apollo Client
- **Routing**: React Router DOM
- **Icons**: Lucide React

## 📋 Prerequisites

Before running this application, you need to:

1. **Create a Nhost project**:
   - Go to [Nhost Console](https://app.nhost.io/)
   - Create a new project
   - Get your backend URL

2. **Set up the database schema** (via Hasura Console):
   
   ```sql
   -- Users table (automatically created by Nhost Auth)
   
   -- Chats table
   CREATE TABLE chats (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     name TEXT,
     created_at TIMESTAMPTZ DEFAULT NOW(),
     updated_at TIMESTAMPTZ DEFAULT NOW()
   );
   
   -- Messages table
   CREATE TABLE messages (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     chat_id UUID REFERENCES chats(id) ON DELETE CASCADE,
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
     content TEXT NOT NULL,
     created_at TIMESTAMPTZ DEFAULT NOW()
   );
   
   -- Chat participants table
   CREATE TABLE chat_participants (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     chat_id UUID REFERENCES chats(id) ON DELETE CASCADE,
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
     joined_at TIMESTAMPTZ DEFAULT NOW(),
     UNIQUE(chat_id, user_id)
   );
   ```

3. **Configure permissions** in Hasura Console:
   - Set up appropriate select/insert/update permissions for each table
   - Enable real-time subscriptions for the messages table

## ⚙️ Configuration

Update the Nhost configuration in `src/config/nhost.ts`:

```typescript
export const nhost = new NhostClient({
  backendUrl: 'https://your-project-id.nhost.run', // Replace with your Nhost backend URL
});
```

Update the GraphQL endpoints in `src/config/apollo.ts`:

```typescript
const httpLink = new HttpLink({
  uri: 'https://your-project-id.nhost.run/v1/graphql',
});

const wsLink = new GraphQLWsLink(
  createClient({
    url: 'wss://your-project-id.nhost.run/v1/graphql',
    // ...
  })
);
```

## 🚀 Getting Started

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the development server**:
   ```bash
   npm run dev
   ```

3. **Open your browser** and navigate to `http://localhost:5173`

## 📱 Usage

1. **Sign Up**: Create a new account with your email and password
2. **Sign In**: Log in to access the chat interface
3. **Start Chatting**: Select a chat from the sidebar or create a new one
4. **Real-time Updates**: Messages appear instantly thanks to GraphQL subscriptions
5. **Sign Out**: Use the logout button in the top-right corner

## 🏗️ Project Structure

```
src/
├── components/
│   ├── auth/
│   │   ├── AuthLayout.tsx      # Authentication layout wrapper
│   │   ├── Login.tsx           # Login form component
│   │   ├── Register.tsx        # Registration form component
│   │   └── ProtectedRoute.tsx  # Route protection wrapper
│   └── chat/
│       ├── ChatLayout.tsx      # Main chat interface layout
│       ├── ChatList.tsx        # Sidebar with chat list
│       ├── ChatView.tsx        # Main chat view with messages
│       └── MessageInput.tsx    # Message input component
├── config/
│   ├── nhost.ts               # Nhost client configuration
│   └── apollo.ts              # Apollo GraphQL client setup
└── App.tsx                    # Main application component
```

## 🔐 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Protected Routes**: Client-side route protection
- **Row Level Security**: Database-level access control (configure in Hasura)
- **Real-time Authorization**: WebSocket connections with JWT tokens

## 🎨 Design System

- **Color Palette**: Blue, purple, and indigo gradients with neutral grays
- **Typography**: Clean, readable fonts with proper hierarchy
- **Components**: Modular, reusable UI components
- **Animations**: Smooth transitions and hover effects
- **Responsive**: Mobile-first design approach

## 📈 Performance

- **Apollo Cache**: Efficient GraphQL query caching
- **Real-time Subscriptions**: WebSocket connections for live updates
- **Code Splitting**: Optimized bundle loading
- **Lazy Loading**: Components loaded as needed

## 🚢 Deployment

This application can be deployed to any static hosting service:

- **Netlify**: Connect your Git repository for automatic deployments
- **Vercel**: Deploy with zero configuration
- **GitHub Pages**: Host directly from your repository

Make sure to update the Nhost backend URLs in your production environment.